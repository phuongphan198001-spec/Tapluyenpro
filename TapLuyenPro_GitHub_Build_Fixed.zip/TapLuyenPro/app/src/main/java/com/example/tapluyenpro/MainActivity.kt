package com.example.tapluyenpro

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tap_luyen", Context.MODE_PRIVATE) }
    private var timer: CountDownTimer? = null
    private var remainingMs = 20 * 60 * 1000L
    private lateinit var timerText: TextView
    private lateinit var progressText: TextView
    private lateinit var morningText: TextView
    private lateinit var eveningText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        buildScreen()
        refreshProgress()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101010.toInt())
        }
        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt(), bold: Boolean = false): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }
        fun button(value: String, action: () -> Unit): Button =
            Button(this).apply {
                text = value
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xFFB71C1C.toInt())
                setOnClickListener { action() }
            }
        root.addView(text("TẬP LUYỆN PRO", 28f, 0xFFFF4040.toInt(), true))
        root.addView(text("Kỷ luật mỗi ngày – tiến bộ từng chút", 14f, 0xFFCCCCCC.toInt()))
        root.addView(text("LỊCH NHẮC TẬP", 18f, 0xFFFF5555.toInt(), true))

        morningText = text("", 16f)
        eveningText = text("", 16f)
        updateTimeLabels()
        root.addView(morningText)
        root.addView(button("Chọn giờ buổi 1") { chooseTime(1) })
        root.addView(eveningText)
        root.addView(button("Chọn giờ buổi 2") { chooseTime(2) })
        root.addView(button("Bật nhắc nhở hằng ngày") { scheduleBoth() })
        root.addView(button("Tắt nhắc nhở") { cancelBoth() })

        root.addView(text("ĐỒNG HỒ TẬP LUYỆN", 18f, 0xFFFF5555.toInt(), true))
        timerText = text("20:00", 32f, 0xFFFFFFFF.toInt(), true)
        timerText.gravity = Gravity.CENTER
        root.addView(timerText)
        root.addView(button("Bắt đầu 20 phút") { startTimer() })
        root.addView(button("Dừng đồng hồ") { stopTimer() })
        root.addView(button("Đặt lại 20 phút") { stopTimer(); remainingMs = 20 * 60 * 1000L; updateTimerText() })

        root.addView(text("TIẾN ĐỘ", 18f, 0xFFFF5555.toInt(), true))
        progressText = text("", 16f)
        root.addView(progressText)
        root.addView(button("Hoàn thành buổi tập hôm nay") {
            val count = prefs.getInt("completed", 0) + 1
            prefs.edit().putInt("completed", count).apply()
            refreshProgress()
            Toast.makeText(this, "Đã lưu tiến độ!", Toast.LENGTH_SHORT).show()
        })
        root.addView(text("Gợi ý: khởi động trước khi tập, uống nước và nghỉ nếu thấy mệt.", 13f, 0xFFBBBBBB.toInt()))
        setContentView(root)
    }

    private fun chooseTime(slot: Int) {
        val keyH = "hour$slot"
        val keyM = "minute$slot"
        val h = prefs.getInt(keyH, if (slot == 1) 6 else 16)
        val m = prefs.getInt(keyM, 0)
        TimePickerDialog(this, { _, hour, minute ->
            prefs.edit().putInt(keyH, hour).putInt(keyM, minute).apply()
            updateTimeLabels()
        }, h, m, true).show()
    }

    private fun updateTimeLabels() {
        fun fmt(slot: Int): String {
            val h = prefs.getInt("hour$slot", if (slot == 1) 6 else 16)
            val m = prefs.getInt("minute$slot", 0)
            return String.format(Locale.getDefault(), "%02d:%02d", h, m)
        }
        morningText.text = "Buổi 1: ${fmt(1)}"
        eveningText.text = "Buổi 2: ${fmt(2)}"
    }

    private fun pending(slot: Int): PendingIntent {
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("title", "Đến giờ tập buổi $slot!").putExtra("id", slot)
        return PendingIntent.getBroadcast(this, slot, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun scheduleBoth() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (slot in 1..2) {
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, prefs.getInt("hour$slot", if (slot == 1) 6 else 16))
                set(Calendar.MINUTE, prefs.getInt("minute$slot", 0))
                set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending(slot))
        }
        Toast.makeText(this, "Đã bật nhắc nhở hằng ngày", Toast.LENGTH_LONG).show()
    }

    private fun cancelBoth() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (slot in 1..2) alarm.cancel(pending(slot))
        Toast.makeText(this, "Đã tắt nhắc nhở", Toast.LENGTH_SHORT).show()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(remainingMs, 1000) {
            override fun onTick(millis: Long) { remainingMs = millis; updateTimerText() }
            override fun onFinish() {
                remainingMs = 0
                updateTimerText()
                Toast.makeText(this@MainActivity, "Hoàn thành thời gian tập!", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun stopTimer() { timer?.cancel(); timer = null }
    private fun updateTimerText() {
        val total = (remainingMs / 1000).toInt()
        timerText.text = String.format(Locale.getDefault(), "%02d:%02d", total / 60, total % 60)
    }
    private fun refreshProgress() {
        progressText.text = "Số buổi đã đánh dấu hoàn thành: ${prefs.getInt("completed", 0)}"
    }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }
}
