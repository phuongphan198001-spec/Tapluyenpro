TAP LUYEN PRO - ANDROID PROJECT
Giao dien den do, ngon ngu tieng Viet.

CHUC NANG
- Chon gio nhac tap cho 2 buoi moi ngay.
- Bat/tat nhac nho hang ngay.
- Dong ho dem nguoc 20 phut.
- Danh dau buoi tap hoan thanh va luu tong so buoi tren may.

CACH TAO APK
1. Cai Android Studio tren may tinh.
2. Giai nen TapLuyenPro.zip.
3. Mo Android Studio > Open > chon thu muc TapLuyenPro.
4. Cho Gradle dong bo va tai cac thanh phan can thiet.
5. Chon Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK duoc tao trong app/build/outputs/apk/debug/.

LUU Y
- Day la ma nguon du an Android, chua phai file APK da bien dich.
- Android 13 tro len can cap quyen thong bao khi app hoi.
- Mot so dien thoai co the gioi han ung dung chay nen; hay cho phep thong bao va hoat dong nen cho app.
- Nhac nho dung AlarmManager khong chinh xac tung giay; he thong co the tre mot chut de tiet kiem pin.

BUILD APK ON GITHUB USING A PHONE
1. Create a new repository on GitHub.
2. Upload the CONTENTS of this folder (including the hidden .github folder).
3. Open the repository's Actions tab.
4. Select "Build Android APK" then "Run workflow" if it has not started automatically.
5. Open the completed run and download the artifact named TapLuyenPro-debug-apk.
6. Extract the artifact ZIP; install app-debug.apk.
